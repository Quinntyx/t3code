package com.swmansion.enriched.markdown.accessibility

import android.content.Context
import android.graphics.Rect
import android.text.Selection
import android.text.Spannable
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewConfiguration
import androidx.appcompat.widget.AppCompatTextView
import com.swmansion.enriched.markdown.spans.LinkPillSpan
import com.swmansion.enriched.markdown.utils.text.span.prepareWidthAwareSpans
import com.swmansion.enriched.markdown.utils.text.view.LinkLongPressMovementMethod
import kotlin.math.abs

/** AppCompatTextView with built-in TalkBack support via MarkdownAccessibilityHelper. */
abstract class AccessibleMarkdownTextView
  @JvmOverloads
  constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
  ) : AppCompatTextView(context, attrs, defStyleAttr) {
    val accessibilityHelper = MarkdownAccessibilityHelper(this)

    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var isScrollGesture = false
    private var scrolledBeforeLongPress = false

    // Cancelled here, not in the movement method: once the platform's own drag starts it stops
    // calling that method, so a scroll is left extending a selection nobody asked for.
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
      when (event.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
          downX = event.x
          downY = event.y
          downTime = event.eventTime
          isScrollGesture = false
        }

        MotionEvent.ACTION_MOVE ->
          if (!isScrollGesture && movedPastSlop(event)) {
            isScrollGesture = true
            // Nothing can be selected yet, so whatever is selected belongs to an earlier gesture.
            scrolledBeforeLongPress = event.eventTime - downTime < ViewConfiguration.getLongPressTimeout()
            cancelPendingPresses()
            if (scrolledBeforeLongPress) clearSelection()
          }

        MotionEvent.ACTION_CANCEL -> {
          isScrollGesture = false
          cancelPendingPresses()
        }

        MotionEvent.ACTION_UP -> {
          // On a scroll the press state is already gone; on a tap the movement method still
          // needs it to deliver the link, so only the pending timer is dropped here.
          if (isScrollGesture) cancelLongPress()
          if (isScrollGesture && scrolledBeforeLongPress) clearSelection()
          isScrollGesture = false
        }
      }
      return super.dispatchTouchEvent(event)
    }

    private fun movedPastSlop(event: MotionEvent): Boolean {
      val slop = ViewConfiguration.get(context).scaledTouchSlop
      return abs(event.x - downX) > slop || abs(event.y - downY) > slop
    }

    private fun cancelPendingPresses() {
      cancelLongPress()
      (movementMethod as? LinkLongPressMovementMethod)?.cancelPendingPress(this)
    }

    private fun clearSelection() {
      val buffer = text as? Spannable ?: return
      if (!hasSelection()) return
      Selection.removeSelection(buffer)
    }

    override fun setText(
      text: CharSequence?,
      type: BufferType?,
    ) {
      // Prime pills before the layout for the new text is built, and register for icons
      // that load later. Runs from the TextView constructor too: use nothing initialized after it.
      val contentWidth = width - compoundPaddingLeft - compoundPaddingRight
      if (contentWidth > 0) prepareWidthAwareSpans(text, contentWidth, includeImages = false)
      LinkPillSpan.registerView(text, this)
      super.setText(text, type)
    }

    override fun onMeasure(
      widthMeasureSpec: Int,
      heightMeasureSpec: Int,
    ) {
      if (MeasureSpec.getMode(widthMeasureSpec) != MeasureSpec.UNSPECIFIED) {
        val width = (MeasureSpec.getSize(widthMeasureSpec) - compoundPaddingLeft - compoundPaddingRight).coerceAtLeast(1)
        // TextView keeps its layout when the new width still fits the old lines.
        if (prepareWidthAwareSpans(text, width, includeImages = false) && layout != null) dropTextLayout()
      }
      super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /**
     * Makes the next measure build a fresh text layout. TextView exposes no direct way:
     * re-setting the text would copy it and clear the selection, while setting the break
     * strategy, even to its current value, discards the layout and nothing else.
     */
    private fun dropTextLayout() {
      breakStrategy = breakStrategy
    }

    override fun dispatchHoverEvent(event: MotionEvent): Boolean =
      accessibilityHelper.dispatchHoverEvent(event) || super.dispatchHoverEvent(event)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean = accessibilityHelper.dispatchKeyEvent(event) || super.dispatchKeyEvent(event)

    override fun onFocusChanged(
      gainFocus: Boolean,
      direction: Int,
      previouslyFocusedRect: Rect?,
    ) {
      super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
      accessibilityHelper.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
    }

    override fun onDetachedFromWindow() {
      // A recycled row is detached mid-gesture and never sees the release, so its press dies here.
      cancelPendingPresses()
      // Before super, and here rather than in a ViewManager's
      // onDropViewInstance: getViewTreeObserver() returns the WINDOW's observer
      // only while the view is attached. Once detached it hands back the view's
      // own floating observer, so a removal then would target the wrong
      // observer and leave the listener on the window.
      accessibilityHelper.cleanup()
      super.onDetachedFromWindow()
    }
  }
