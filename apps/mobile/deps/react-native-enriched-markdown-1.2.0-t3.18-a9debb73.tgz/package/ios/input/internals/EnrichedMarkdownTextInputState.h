#pragma once
#include <memory>

namespace facebook::react {

class EnrichedMarkdownTextInputState {
public:
  EnrichedMarkdownTextInputState() = default;
  EnrichedMarkdownTextInputState(int counter, std::shared_ptr<void> ref) : counter_(counter), viewRef_(ref) {}

  int getHeightRecalculationCounter() const {
    return counter_;
  }
  std::shared_ptr<void> getComponentViewRef() const {
    return viewRef_;
  }
  EnrichedMarkdownTextInputState withHeightRecalculationCounter(int counter, std::shared_ptr<void> ref) const {
    return EnrichedMarkdownTextInputState(counter, ref);
  }

private:
  int counter_{0};
  std::shared_ptr<void> viewRef_{nullptr};
};

} // namespace facebook::react
